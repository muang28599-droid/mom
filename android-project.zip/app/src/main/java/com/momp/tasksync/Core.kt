package com.momp.tasksync

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** ดัง 5 นาที สลับเงียบ 5 นาที */
const val CYCLE = 5 * 60 * 1000L

data class Task(
    val id: String,
    val title: String,
    val due: Long,
    val status: String,
    val nudge: Long,
    val assignee: String
) {
    val base: Long get() = maxOf(due, nudge)
}

fun parseTasks(json: String, myId: String): List<Task> {
    val out = ArrayList<Task>()
    try {
        val o = JSONObject(json)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val t = o.optJSONObject(k) ?: continue
            val a = t.optString("assignee", "")
            if (a.isNotEmpty() && a != myId) continue
            out.add(
                Task(
                    k,
                    t.optString("title", ""),
                    t.optLong("due", 0L),
                    t.optString("status", "pending"),
                    t.optLong("nudge", 0L),
                    a
                )
            )
        }
    } catch (e: Exception) {
    }
    return out.sortedBy { it.due }
}

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", Context.MODE_PRIVATE)

    fun room(c: Context): String = p(c).getString("room", "") ?: ""
    fun name(c: Context): String = p(c).getString("name", "") ?: ""
    fun soundUri(c: Context): String = p(c).getString("sound", "") ?: ""
    fun soundName(c: Context): String = p(c).getString("soundName", "") ?: ""
    fun active(c: Context): Boolean = p(c).getBoolean("active", false)
    fun tasksJson(c: Context): String = p(c).getString("tasks", "{}") ?: "{}"

    fun set(c: Context, k: String, v: String) {
        p(c).edit().putString(k, v).apply()
    }

    fun setActive(c: Context, v: Boolean) {
        p(c).edit().putBoolean("active", v).apply()
    }

    fun saveTasks(c: Context, j: String) {
        p(c).edit().putString("tasks", j).apply()
    }

    fun memberId(c: Context): String {
        val old = p(c).getString("mid", null)
        if (old != null) return old
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        val id = "n" + (1..8).map { chars.random() }.joinToString("")
        p(c).edit().putString("mid", id).apply()
        return id
    }

    fun scheduled(c: Context): Set<String> =
        p(c).getStringSet("sched", emptySet()) ?: emptySet()

    fun setScheduled(c: Context, s: Set<String>) {
        p(c).edit().putStringSet("sched", HashSet(s)).apply()
    }

    /** อัปเดตสถานะในเครื่องทันที เพื่อให้เสียงหยุดโดยไม่ต้องรอเน็ต */
    fun setStatus(c: Context, id: String, st: String) {
        try {
            val o = JSONObject(tasksJson(c))
            o.optJSONObject(id)?.put("status", st)
            saveTasks(c, o.toString())
        } catch (e: Exception) {
        }
    }
}

object Api {
    // TODO: ถ้าใช้ฐานข้อมูลอื่น ให้เปลี่ยน URL นี้ให้ตรงกับ Realtime Database ของคุณ
    const val BASE = "https://momp-37901-default-rtdb.firebaseio.com"

    @Volatile
    private var cur: HttpURLConnection? = null

    fun get(path: String): String? {
        return try {
            val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            val s = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            s
        } catch (e: Exception) {
            null
        }
    }

    fun send(path: String, method: String, body: String): Boolean {
        return try {
            val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            if (method == "PATCH") {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            } else {
                c.requestMethod = method
            }
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (e: Exception) {
            false
        }
    }

    fun sendRetry(path: String, method: String, body: String) {
        for (i in 1..4) {
            if (send(path, method, body)) return
            try {
                Thread.sleep(2500)
            } catch (e: Exception) {
            }
        }
    }

    /** ฟังการเปลี่ยนแปลงแบบเรียลไทม์ (Server-Sent Events) แล้วเรียก onEvent ทุกครั้งที่มีข้อมูลเปลี่ยน */
    fun stream(path: String, onEvent: () -> Unit, stop: () -> Boolean) {
        while (!stop()) {
            try {
                val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "text/event-stream")
                c.connectTimeout = 10000
                c.readTimeout = 70000
                cur = c
                BufferedReader(InputStreamReader(c.inputStream)).use { r ->
                    var line = r.readLine()
                    while (line != null && !stop()) {
                        if (line.startsWith("event: put") || line.startsWith("event: patch")) onEvent()
                        line = r.readLine()
                    }
                }
            } catch (e: Exception) {
            }
            if (stop()) break
            try {
                Thread.sleep(3000)
            } catch (e: Exception) {
            }
        }
    }

    fun stopStream() {
        try {
            cur?.disconnect()
        } catch (e: Exception) {
        }
    }
}

object Notif {
    const val CH_SYNC = "sync"
    const val CH_ALARM = "alarm"

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SYNC, "รอรับงาน", NotificationManager.IMPORTANCE_LOW)
        )
        val ch = NotificationChannel(CH_ALARM, "เสียงปลุกงาน", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        nm.createNotificationChannel(ch)
    }
}

object Sound {
    fun start(c: Context, loop: Boolean): MediaPlayer? {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        fun tryUri(u: Uri): MediaPlayer? {
            return try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(attrs)
                mp.setDataSource(c, u)
                mp.isLooping = loop
                mp.prepare()
                mp.start()
                mp
            } catch (e: Exception) {
                null
            }
        }

        var mp: MediaPlayer? = null
        val custom = Store.soundUri(c)
        if (custom.isNotEmpty()) mp = tryUri(Uri.parse(custom))
        if (mp == null) mp = tryUri(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        return mp
    }
}

object Alarms {
    fun isRinging(t: Task, now: Long): Boolean {
        if (t.status != "pending") return false
        val e = now - t.base
        return e >= 0 && (e / CYCLE) % 2L == 0L
    }

    /** เวลาที่รอบเสียงดังรอบถัดไปเริ่ม (ถ้ากำลังดังอยู่ = ตอนนี้) */
    private fun nextRing(t: Task, now: Long): Long {
        val e = now - t.base
        if (e < 0) return t.base
        val k = e / CYCLE
        return if (k % 2L == 0L) now else t.base + (k + 1) * CYCLE
    }

    private fun pi(c: Context, id: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("id", id)
            .setData(Uri.parse("tasksync:$id"))
        return PendingIntent.getBroadcast(
            c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, tasks: List<Task>) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val keep = HashSet<String>()
        for (t in tasks) {
            if (t.status != "pending") continue
            keep.add(t.id)
            if (isRinging(t, now)) {
                AlarmService.ring(c, t.id)
            } else {
                val show = PendingIntent.getActivity(
                    c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(nextRing(t, now), show), pi(c, t.id))
            }
        }
        for (id in Store.scheduled(c)) {
            if (id !in keep) am.cancel(pi(c, id))
        }
        Store.setScheduled(c, keep)
    }

    fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (id in Store.scheduled(c)) am.cancel(pi(c, id))
        Store.setScheduled(c, emptySet())
        AlarmService.stopAll(c)
    }
}
