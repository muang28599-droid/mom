package com.momp.tasksync

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** หน้าตั้งค่าเครื่องผู้รับงาน (ลูก) */
class MainActivity : Activity() {
    private lateinit var roomIn: EditText
    private lateinit var nameIn: EditText
    private lateinit var info: TextView
    private lateinit var startBtn: Button
    private var testMp: MediaPlayer? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun btn(t: String, bg: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 17f
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor(bg))
        b.minHeight = dp(56)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        b.layoutParams = lp
        b.setOnClickListener { f() }
        return b
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.textSize = 20f
        e.setSingleLine(true)
        return e
    }

    private fun buildChooser() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(80), dp(24), dp(24))
        setContentView(col)
        val t = TextView(this)
        t.text = "สั่งงานลูก"
        t.textSize = 30f
        t.setTypeface(null, Typeface.BOLD)
        col.addView(t)
        val s = TextView(this)
        s.text = "เครื่องนี้ใช้เป็นของใคร?"
        s.textSize = 18f
        s.setPadding(0, dp(8), 0, dp(24))
        col.addView(s)
        col.addView(btn("👩 ผู้สั่งงาน (แม่)", "#e8590c") {
            Store.set(this, "role", "parent")
            startActivity(Intent(this, ParentActivity::class.java))
            finish()
        })
        col.addView(btn("🧒 ผู้รับงาน (ลูก)", "#1f3a2e") {
            Store.set(this, "role", "child")
            recreate()
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val role = Store.role(this)
        if (role == "parent") {
            startActivity(Intent(this, ParentActivity::class.java))
            finish()
            return
        }
        if (role != "child") {
            buildChooser()
            return
        }
        if (Store.active(this)) {
            startActivity(Intent(this, ChildWaitActivity::class.java))
            finish()
            return
        }
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(30))
        sv.addView(col)
        setContentView(sv)

        val title = TextView(this)
        title.text = "ตั้งค่าเครื่องผู้รับงาน"
        title.textSize = 24f
        title.setTypeface(null, Typeface.BOLD)
        col.addView(title)

        roomIn = field("รหัสห้อง (จากเครื่องแม่)")
        roomIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        nameIn = field("ชื่อของคุณ เช่น น้องบอม")
        col.addView(roomIn)
        col.addView(nameIn)

        info = TextView(this)
        info.textSize = 16f
        info.setPadding(0, dp(16), 0, dp(6))
        col.addView(info)

        col.addView(btn("ขั้นที่ 1: ให้สิทธิ์ที่จำเป็น (กดซ้ำจนครบ)", "#e8590c") { askPerms() })
        col.addView(btn("ขั้นที่ 2: 🎵 เลือกไฟล์เสียงปลุก", "#1f3a2e") { pickSound() })
        col.addView(btn("🔊 ทดสอบเสียง (4 วินาที)", "#1f3a2e") { test() })
        col.addView(btn("ใช้เสียงปลุกของเครื่อง", "#6b7280") {
            Store.set(this, "sound", "")
            Store.set(this, "soundName", "")
            refresh()
        })
        startBtn = btn("✅ ยืนยัน แล้วเข้าหน้ารอรับงาน", "#2f9e44") { toggle() }
        col.addView(startBtn)
        col.addView(btn("เปลี่ยนบทบาท (แม่/ลูก)", "#6b7280") {
            Store.set(this, "role", "")
            recreate()
        })

        if (Store.active(this)) SyncService.start(this)
    }

    override fun onResume() {
        super.onResume()
        if (!::roomIn.isInitialized) return
        if (roomIn.text.isEmpty()) roomIn.setText(Store.room(this))
        if (nameIn.text.isEmpty()) nameIn.setText(Store.name(this))
        refresh()
    }

    private fun refresh() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val noti = if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
        val full = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
        val batt = pm.isIgnoringBatteryOptimizations(packageName)
        fun m(ok: Boolean) = if (ok) "✅" else "❌"
        val snd = Store.soundName(this).ifEmpty { "เสียงปลุกของเครื่อง" }
        info.text = "${m(noti)} แจ้งเตือน\n${m(full)} เด้งเต็มจอ\n${m(batt)} ทำงานเบื้องหลังไม่ถูกจำกัด\n🎵 เสียง: $snd"
    }

    private fun askPerms() {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                return
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                )
                return
            }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
                return
            }
            toast("ให้สิทธิ์ครบแล้ว")
        } catch (e: Exception) {
            toast("เปิดหน้าตั้งค่าไม่ได้ ลองไปที่ ตั้งค่า > แอป > สั่งงานลูก")
        }
    }

    private fun pickSound() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        startActivityForResult(i, 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (requestCode == 2 && resultCode == RESULT_OK && u != null) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Store.set(this, "sound", u.toString())
            Store.set(this, "soundName", nameOf(u))
            refresh()
        }
    }

    private fun nameOf(u: Uri): String {
        try {
            val c = contentResolver.query(u, null, null, null, null)
            if (c != null) {
                c.use {
                    if (it.moveToFirst()) {
                        val ix = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (ix >= 0) return it.getString(ix)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return "ไฟล์เสียง"
    }

    private fun test() {
        testMp?.release()
        testMp = Sound.start(this, false)
        Handler(Looper.getMainLooper()).postDelayed({
            testMp?.release()
            testMp = null
        }, 4000)
    }

    private fun permsOk(): Boolean {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val noti = if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else true
        val full = if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true
        return noti && full && pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun toggle() {
        val r = roomIn.text.toString().trim().uppercase()
        val n = nameIn.text.toString().trim()
        if (r.length < 4) {
            toast("ใส่รหัสห้องก่อน")
            return
        }
        if (n.isEmpty()) {
            toast("ใส่ชื่อของคุณก่อน")
            return
        }
        if (!permsOk()) {
            toast("ยังให้สิทธิ์ไม่ครบ กดปุ่มขั้นที่ 1 ซ้ำจนติ๊กเขียวครบทุกข้อ")
            return
        }
        startBtn.isEnabled = false
        Thread {
            val meta = Api.get("rooms/$r/meta")
            runOnUiThread {
                startBtn.isEnabled = true
                if (meta == null) {
                    toast("ต่อเน็ตไม่ได้ ลองใหม่อีกครั้ง")
                } else if (meta == "null") {
                    toast("ไม่พบห้องนี้ ตรวจรหัสอีกครั้ง")
                } else {
                    Store.set(this, "room", r)
                    Store.set(this, "name", n)
                    Store.setActive(this, true)
                    SyncService.start(this)
                    startActivity(Intent(this, ChildWaitActivity::class.java))
                    finish()
                }
            }
        }.start()
    }

    override fun onDestroy() {
        testMp?.release()
        super.onDestroy()
    }
}
