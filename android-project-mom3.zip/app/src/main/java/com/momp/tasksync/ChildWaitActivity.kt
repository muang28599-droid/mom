package com.momp.tasksync

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** หน้ารอรับงานของลูก: ตั้งค่าเสร็จแล้ว แสดงสถานะและงานที่ได้รับ */
class ChildWaitActivity : Activity() {
    private lateinit var listBox: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            h.postDelayed(this, 3000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

    private fun tv(t: String, size: Float, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(6), 0, dp(4))
        return v
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Store.active(this)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#f4efe4"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(50), dp(20), dp(30))
        sv.addView(col)
        setContentView(sv)

        col.addView(tv("🟢 กำลังรอรับงานจากแม่", 26f, true))
        col.addView(tv("ห้อง ${Store.room(this)} · ${Store.name(this)}", 18f, false))
        val snd = Store.soundName(this).ifEmpty { "เสียงปลุกของเครื่อง" }
        col.addView(tv("🎵 $snd", 15f, false))
        col.addView(tv("ปล่อยแอปไว้เบื้องหลังได้เลย เมื่อถึงเวลาจะมีเสียงปลุกดังและเด้งขึ้นเต็มจอ", 14f, false))
        col.addView(tv("งานของคุณ", 18f, true))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        col.addView(listBox)

        val stop = Button(this)
        stop.text = "หยุดรอรับงาน / แก้ไขการตั้งค่า"
        stop.textSize = 16f
        stop.isAllCaps = false
        stop.setTextColor(Color.WHITE)
        stop.setBackgroundColor(Color.parseColor("#6b7280"))
        stop.minHeight = dp(52)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(24)
        stop.layoutParams = lp
        stop.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("หยุดรอรับงาน? เสียงปลุกจะไม่ดังจนกว่าจะเริ่มใหม่")
                .setPositiveButton("หยุด") { _, _ ->
                    Store.setActive(this, false)
                    SyncService.stop(this)
                    Alarms.cancelAll(this)
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                .setNegativeButton("ยกเลิก", null)
                .show()
        }
        col.addView(stop)
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun render() {
        listBox.removeAllViews()
        val now = System.currentTimeMillis()
        val tasks = parseTasks(Store.tasksJson(this), Store.memberId(this))
            .filter { it.status != "done" }
        if (tasks.isEmpty()) {
            listBox.addView(tv("ยังไม่มีงานค้าง", 15f, false))
            return
        }
        for (t in tasks) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(dp(14), dp(12), dp(14), dp(12))
            val gd = GradientDrawable()
            gd.setColor(Color.WHITE)
            gd.cornerRadius = dp(14).toFloat()
            gd.setStroke(dp(1), Color.parseColor("#e3dccb"))
            c.background = gd
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(10)
            c.layoutParams = lp
            c.addView(tv(t.title, 18f, true))
            val st = when {
                t.status == "ack" -> "✔ รับทราบแล้ว"
                now >= t.base -> "⏰ ถึงเวลาแล้ว"
                else -> "⏳ ดังตอน ${hm(t.base)}"
            }
            c.addView(tv(st, 14f, false))
            listBox.addView(c)
        }
    }
}
