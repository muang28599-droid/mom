package com.momp.tasksync

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** หน้าของแม่: สร้าง/เข้าห้อง เลือกลูก สั่งงาน และดูสถานะงานแบบสด */
class ParentActivity : Activity() {
    private lateinit var setupBox: LinearLayout
    private lateinit var mainBox: LinearLayout
    private lateinit var roomLbl: TextView
    private lateinit var whoRow: LinearLayout
    private lateinit var timeRow: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var titleIn: EditText
    private lateinit var codeIn: EditText

    private var gen = 0
    @Volatile
    private var alive = false
    private var members = JSONObject()
    private var tasksObj = JSONObject()
    private var selWho: String? = null
    private var selMin = 15
    private var absAt = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
    }

    private fun obj(s: String): JSONObject = try {
        JSONObject(s)
    } catch (e: Exception) {
        JSONObject()
    }

    private fun hm(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

    private fun hashOf(s: String): String {
        var h = 5381
        for (ch in s) h = (h shl 5) + h + ch.code
        return "h" + java.lang.Long.toString(h.toLong() and 0xffffffffL, 36)
    }

    private fun btn(t: String, bg: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 17f
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor(bg))
        b.minHeight = dp(52)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        b.layoutParams = lp
        b.setOnClickListener { f() }
        return b
    }

    private fun chip(t: String, sel: Boolean, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 15f
        b.isAllCaps = false
        b.minHeight = dp(48)
        b.setTextColor(if (sel) Color.WHITE else Color.parseColor("#23312b"))
        b.setBackgroundColor(Color.parseColor(if (sel) "#e8590c" else "#e8e2d2"))
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.rightMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { f() }
        return b
    }

    private fun label(t: String, size: Float, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(10), 0, dp(4))
        return v
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#f4efe4"))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(40), dp(18), dp(30))
        sv.addView(col)
        setContentView(sv)

        col.addView(label("สั่งงานลูก · เครื่องแม่", 24f, true))

        // ---- ยังไม่มีห้อง ----
        setupBox = LinearLayout(this)
        setupBox.orientation = LinearLayout.VERTICAL
        setupBox.addView(label("สร้างห้องใหม่ หรือใส่รหัสห้องที่มีอยู่", 16f, false))
        setupBox.addView(btn("สร้างห้องใหม่", "#e8590c") { createRoom() })
        codeIn = EditText(this)
        codeIn.hint = "รหัสห้อง"
        codeIn.textSize = 20f
        codeIn.setSingleLine(true)
        codeIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        setupBox.addView(codeIn)
        setupBox.addView(btn("เข้าร่วมห้องด้วยรหัส", "#1f3a2e") { joinRoom() })
        col.addView(setupBox)

        // ---- มีห้องแล้ว ----
        mainBox = LinearLayout(this)
        mainBox.orientation = LinearLayout.VERTICAL
        roomLbl = label("", 22f, true)
        mainBox.addView(roomLbl)

        mainBox.addView(label("สั่งให้ใคร", 15f, false))
        val hs = HorizontalScrollView(this)
        whoRow = LinearLayout(this)
        whoRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(whoRow)
        mainBox.addView(hs)

        mainBox.addView(label("ชื่องาน", 15f, false))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        titleIn = EditText(this)
        titleIn.hint = "เช่น รดน้ำต้นไม้"
        titleIn.textSize = 18f
        titleIn.setSingleLine(true)
        row.addView(titleIn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(chip("🎤", false) { voice() })
        row.addView(chip("＋", false) { showHistory() })
        mainBox.addView(row)

        mainBox.addView(label("เวลา", 15f, false))
        val hs2 = HorizontalScrollView(this)
        timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        hs2.addView(timeRow)
        mainBox.addView(hs2)

        mainBox.addView(btn("สั่งงาน", "#e8590c") { send() })
        mainBox.addView(label("สถานะงาน", 18f, true))
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        mainBox.addView(listBox)
        mainBox.addView(btn("ออกจากห้อง", "#6b7280") { leaveRoom() })
        col.addView(mainBox)

        col.addView(btn("เปลี่ยนบทบาท (แม่/ลูก)", "#6b7280") {
            Store.set(this, "role", "")
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        })

        showState()
    }

    override fun onResume() {
        super.onResume()
        startPoll()
    }

    override fun onPause() {
        super.onPause()
        alive = false
        gen++
    }

    private fun showState() {
        val has = Store.room(this).isNotEmpty()
        setupBox.visibility = if (has) View.GONE else View.VISIBLE
        mainBox.visibility = if (has) View.VISIBLE else View.GONE
        roomLbl.text = "ห้อง " + Store.room(this)
        renderTime()
        render()
    }

    // ---------- ห้อง ----------
    private fun createRoom() {
        Thread {
            val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            var made: String? = null
            for (i in 1..6) {
                val c = (1..5).map { chars.random() }.joinToString("")
                val m = Api.get("rooms/$c/meta") ?: break
                if (m == "null") {
                    if (Api.send("rooms/$c/meta", "PUT", "{\"createdAt\":{\".sv\":\"timestamp\"}}")) made = c
                    break
                }
            }
            val r = made
            runOnUiThread {
                if (r != null) enterRoom(r) else toast("สร้างห้องไม่สำเร็จ ตรวจอินเทอร์เน็ตแล้วลองใหม่")
            }
        }.start()
    }

    private fun joinRoom() {
        val c = codeIn.text.toString().trim().uppercase()
        if (c.length < 4) {
            toast("ใส่รหัสห้อง 4-6 ตัว")
            return
        }
        Thread {
            val m = Api.get("rooms/$c/meta")
            runOnUiThread {
                if (m == null) toast("ต่อเน็ตไม่ได้ ลองใหม่อีกครั้ง")
                else if (m == "null") toast("ไม่พบห้องนี้ ตรวจรหัสอีกครั้ง")
                else enterRoom(c)
            }
        }.start()
    }

    private fun enterRoom(c: String) {
        Store.set(this, "room", c)
        members = JSONObject()
        tasksObj = JSONObject()
        selWho = null
        showState()
    }

    private fun leaveRoom() {
        AlertDialog.Builder(this)
            .setMessage("ออกจากห้องนี้?")
            .setPositiveButton("ออก") { _, _ ->
                Store.set(this, "room", "")
                members = JSONObject()
                tasksObj = JSONObject()
                showState()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    // ---------- ดึงข้อมูลสด ----------
    private fun startPoll() {
        alive = true
        val my = ++gen
        Thread {
            while (alive && my == gen) {
                val room = Store.room(this)
                if (room.isNotEmpty()) {
                    val t = Api.get("rooms/$room/tasks")
                    val m = Api.get("rooms/$room/members")
                    runOnUiThread {
                        if (alive && my == gen) {
                            if (t != null) tasksObj = obj(t)
                            if (m != null) members = obj(m)
                            render()
                        }
                    }
                }
                try {
                    Thread.sleep(3000)
                } catch (e: Exception) {
                }
            }
        }.start()
    }

    private fun memberIds(): List<String> {
        val out = ArrayList<String>()
        val ks = members.keys()
        while (ks.hasNext()) out.add(ks.next())
        return out
    }

    private fun render() {
        renderWho()
        renderList()
    }

    private fun renderWho() {
        whoRow.removeAllViews()
        val ids = memberIds()
        if (ids.isEmpty()) {
            selWho = null
            val v = TextView(this)
            v.text = "ยังไม่มีลูกในห้อง ให้ลูกเปิดแอป ใส่รหัสห้อง ตั้งชื่อ แล้วกดเริ่มรอรับงาน"
            v.textSize = 14f
            whoRow.addView(v)
            return
        }
        val sw = selWho
        if (sw == null || (sw != "all" && !ids.contains(sw))) selWho = if (ids.size > 1) "all" else ids[0]
        if (ids.size > 1) {
            whoRow.addView(chip("👥 ทุกคน", selWho == "all") {
                selWho = "all"
                renderWho()
            })
        }
        for (id in ids) {
            val o = members.optJSONObject(id)
            val name = o?.optString("name", "") ?: ""
            val on = o?.optBoolean("online", false) ?: false
            whoRow.addView(chip((if (on) "🟢 " else "⚪ ") + name, selWho == id) {
                selWho = id
                renderWho()
            })
        }
    }

    private fun renderTime() {
        timeRow.removeAllViews()
        for (m in listOf(15, 30, 60)) {
            timeRow.addView(chip(if (m == 60) "+1 ชม." else "+$m นาที", selMin == m) {
                selMin = m
                renderTime()
            })
        }
        timeRow.addView(chip(if (selMin < 0) "🕐 " + hm(absAt) else "🕐 เลือกเวลา", selMin < 0) { pickTime() })
    }

    private fun pickTime() {
        val now = Calendar.getInstance()
        TimePickerDialog(this, { _, hh, mm ->
            val t = Calendar.getInstance()
            t.set(Calendar.HOUR_OF_DAY, hh)
            t.set(Calendar.MINUTE, mm)
            t.set(Calendar.SECOND, 0)
            t.set(Calendar.MILLISECOND, 0)
            if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1)
            absAt = t.timeInMillis
            selMin = -1
            renderTime()
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val gd = GradientDrawable()
        gd.setColor(Color.WHITE)
        gd.cornerRadius = dp(14).toFloat()
        gd.setStroke(dp(1), Color.parseColor("#e3dccb"))
        c.background = gd
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        c.layoutParams = lp
        return c
    }

    private fun renderList() {
        listBox.removeAllViews()
        val arr = ArrayList<Pair<String, JSONObject>>()
        val ks = tasksObj.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            val o = tasksObj.optJSONObject(k) ?: continue
            arr.add(Pair(k, o))
        }
        if (arr.isEmpty()) {
            val v = TextView(this)
            v.text = "ยังไม่มีงาน"
            listBox.addView(v)
            return
        }
        arr.sortWith(
            compareBy<Pair<String, JSONObject>>(
                { it.second.optString("status") == "done" },
                { it.second.optLong("due") }
            )
        )
        val now = System.currentTimeMillis()
        for ((id, t) in arr) {
            val st = t.optString("status", "pending")
            val aid = t.optString("assignee", "")
            val who = members.optJSONObject(aid)?.optString("name", "")
                ?: t.optString("assigneeName", "").ifEmpty { "ทุกคน" }
            val due = t.optLong("due")
            val late = if (st != "done" && now > due) " · เลยเวลา" else ""
            val stTxt = when (st) {
                "ack" -> "✔ รับทราบแล้ว"
                "done" -> "✅ ทำเสร็จแล้ว"
                else -> "⏳ รอรับทราบ"
            }
            val c = card()
            val title = TextView(this)
            title.text = t.optString("title", "")
            title.textSize = 18f
            title.setTypeface(null, Typeface.BOLD)
            c.addView(title)
            val info = TextView(this)
            info.text = "👤 $who · ⏰ ${hm(due)}$late\n$stTxt"
            info.textSize = 14f
            info.setPadding(0, dp(4), 0, dp(6))
            c.addView(info)
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            if (st != "done") r.addView(chip("🔔 เตือนซ้ำ", false) { nudge(id) })
            r.addView(chip("🗑 ลบ", false) { delete(id) })
            c.addView(r)
            if (st == "done") c.alpha = 0.6f
            listBox.addView(c)
        }
    }

    // ---------- การกระทำ ----------
    private fun nudge(id: String) {
        val room = Store.room(this)
        val now = System.currentTimeMillis()
        tasksObj.optJSONObject(id)?.put("status", "pending")
        tasksObj.optJSONObject(id)?.put("nudge", now)
        render()
        Thread {
            Api.sendRetry("rooms/$room/tasks/$id", "PATCH", "{\"nudge\":$now,\"status\":\"pending\"}")
        }.start()
        toast("เตือนซ้ำแล้ว")
    }

    private fun delete(id: String) {
        AlertDialog.Builder(this)
            .setMessage("ลบงานนี้?")
            .setPositiveButton("ลบ") { _, _ ->
                val room = Store.room(this)
                tasksObj.remove(id)
                render()
                Thread { Api.sendRetry("rooms/$room/tasks/$id", "DELETE", "") }.start()
            }
            .setNegativeButton("ยกเลิก", null)
            .show()
    }

    private fun send() {
        val title = titleIn.text.toString().trim()
        if (title.isEmpty()) {
            toast("พิมพ์หรือพูดชื่องานก่อน")
            return
        }
        val ids = memberIds()
        val who = selWho
        if (ids.isEmpty() || who == null) {
            toast("ยังไม่มีลูกในห้อง ให้ลูกเปิดแอปและกดเริ่มรอรับงานก่อน")
            return
        }
        val now = System.currentTimeMillis()
        val due = if (selMin >= 0) now + selMin * 60000L else absAt
        val targets = if (who == "all") ids else listOf(who)
        val body = JSONObject()
        var n = 0
        for (m in targets) {
            n++
            val o = JSONObject()
            o.put("title", title)
            o.put("due", due)
            o.put("status", "pending")
            o.put("assignee", m)
            o.put("assigneeName", members.optJSONObject(m)?.optString("name", "") ?: "")
            o.put("createdAt", JSONObject().put(".sv", "timestamp"))
            body.put("t" + java.lang.Long.toString(now, 36) + "x" + n + (1..3).map { "abcdefghij".random() }.joinToString(""), o)
        }
        val room = Store.room(this)
        val hk = hashOf(title)
        Thread {
            val ok = Api.send("rooms/$room/tasks", "PATCH", body.toString())
            if (ok) {
                val old = Api.get("rooms/$room/history/$hk")
                val q = JSONObject.quote(title)
                val hb = if (old == null || old == "null") {
                    "{\"title\":$q,\"count\":0,\"last\":$now}"
                } else {
                    "{\"title\":$q,\"last\":$now}"
                }
                Api.send("rooms/$room/history/$hk", "PATCH", hb)
            }
            runOnUiThread {
                if (ok) {
                    titleIn.setText("")
                    toast("สั่งงานแล้ว ดังตอน " + hm(due))
                } else {
                    toast("ส่งไม่สำเร็จ ตรวจอินเทอร์เน็ตแล้วลองใหม่")
                }
            }
        }.start()
    }

    private fun showHistory() {
        val room = Store.room(this)
        Thread {
            val h = obj(Api.get("rooms/$room/history") ?: "{}")
            val list = ArrayList<Pair<String, Int>>()
            val ks = h.keys()
            while (ks.hasNext()) {
                val o = h.optJSONObject(ks.next()) ?: continue
                list.add(Pair(o.optString("title", ""), o.optInt("count", 0)))
            }
            list.sortByDescending { it.second }
            runOnUiThread {
                if (list.isEmpty()) {
                    toast("ยังไม่มีประวัติงาน")
                } else {
                    val titles = list.map { it.first }.toTypedArray()
                    AlertDialog.Builder(this)
                        .setTitle("งานที่เคยสั่ง")
                        .setItems(titles) { _, i -> titleIn.setText(titles[i]) }
                        .setNegativeButton("ปิด", null)
                        .show()
                }
            }
        }.start()
    }

    private fun voice() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดชื่องาน")
            startActivityForResult(i, 31)
        } catch (e: ActivityNotFoundException) {
            toast("เครื่องนี้ไม่รองรับการพูดเป็นข้อความ")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 31 && resultCode == RESULT_OK) {
            val r = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (r != null && r.isNotEmpty()) titleIn.setText(r[0])
        }
    }
}
