package com.momp.tasksync

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** เล่นเสียงปลุก + สั่น + เด้งหน้าจอ จนกว่าจะกดรับทราบ/เสร็จ หรือครบรอบ 5 นาที */
class AlarmService : Service() {
    private val ringing = LinkedHashSet<String>()
    private var player: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            scan()
            if (ticking) h.postDelayed(this, 1000)
        }
    }

    companion object {
        fun ring(c: Context, id: String) {
            ContextCompat.startForegroundService(
                c, Intent(c, AlarmService::class.java).putExtra("id", id)
            )
        }

        fun stopAll(c: Context) {
            c.stopService(Intent(c, AlarmService::class.java))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        Notif.ensureChannels(this)
        val id = i?.getStringExtra("id")
        if (id != null) ringing.add(id)
        val n = buildNote()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
        if (player == null) startSound()
        if (wl == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tasksync:ring")
            wl?.acquire(6 * 60 * 1000L)
        }
        if (!ticking) {
            ticking = true
            h.postDelayed(tick, 1000)
        }
        return START_NOT_STICKY
    }

    private fun scan() {
        val now = System.currentTimeMillis()
        val map = parseTasks(Store.tasksJson(this), Store.memberId(this)).associateBy { it.id }
        val before = ringing.size
        ringing.retainAll { id ->
            val t = map[id]
            t != null && Alarms.isRinging(t, now)
        }
        if (ringing.isEmpty()) {
            finishRing()
            return
        }
        if (ringing.size != before) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(2, buildNote())
        }
    }

    private fun finishRing() {
        ticking = false
        h.removeCallbacks(tick)
        stopSound()
        Alarms.schedule(this, parseTasks(Store.tasksJson(this), Store.memberId(this)))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startSound() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(
                AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0
            )
        } catch (e: Exception) {
        }
        player = Sound.start(this, true)
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 300), 0))
        } catch (e: Exception) {
        }
    }

    private fun stopSound() {
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        try {
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        } catch (e: Exception) {
        }
        try {
            if (wl?.isHeld == true) wl?.release()
        } catch (e: Exception) {
        }
        wl = null
    }

    private fun buildNote(): Notification {
        val tasks = parseTasks(Store.tasksJson(this), Store.memberId(this))
            .filter { it.id in ringing }
        val text = if (tasks.isEmpty()) "ถึงเวลาแล้ว" else tasks.joinToString(", ") { it.title }
        val pi = PendingIntent.getActivity(
            this, 1,
            Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Notif.CH_ALARM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ แม่สั่งงาน")
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
    }

    override fun onDestroy() {
        ticking = false
        h.removeCallbacks(tick)
        stopSound()
        super.onDestroy()
    }
}
