package com.momp.tasksync

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        AlarmService.ring(c, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store.active(c)) {
            SyncService.start(c)
            Alarms.schedule(c, parseTasks(Store.tasksJson(c), Store.memberId(c)))
        }
    }
}
