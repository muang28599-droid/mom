package com.momp.tasksync

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** บริการเบื้องหลัง: ฟังงานใหม่จาก Firebase แล้วตั้งนาฬิกาปลุกให้ตรงเวลา */
class SyncService : Service() {
    @Volatile
    private var running = false

    companion object {
        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, SyncService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, SyncService::class.java))
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        Notif.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, Notif.CH_SYNC)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("รอรับงานจากแม่")
            .setContentText("ห้อง ${Store.room(this)} · ${Store.name(this)}")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (!running) {
            running = true
            Thread { loop() }.start()
        }
        return START_STICKY
    }

    private fun loop() {
        val room = Store.room(this)
        val mid = Store.memberId(this)
        Api.sendRetry(
            "rooms/$room/members/$mid",
            "PATCH",
            "{\"name\":" + JSONObject.quote(Store.name(this)) + ",\"online\":true}"
        )
        Thread {
            while (running) {
                sync()
                try {
                    Thread.sleep(30000)
                } catch (e: Exception) {
                }
            }
        }.start()
        Api.stream("rooms/$room/tasks", { sync() }, { !running })
    }

    @Synchronized
    private fun sync() {
        val j = Api.get("rooms/${Store.room(this)}/tasks") ?: return
        Store.saveTasks(this, j)
        Alarms.schedule(this, parseTasks(j, Store.memberId(this)))
    }

    override fun onDestroy() {
        running = false
        Api.stopStream()
        val room = Store.room(this)
        val mid = Store.memberId(this)
        Thread { Api.send("rooms/$room/members/$mid", "PATCH", "{\"online\":false}") }.start()
        super.onDestroy()
    }
}
