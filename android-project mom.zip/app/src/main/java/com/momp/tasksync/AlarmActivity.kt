package com.momp.tasksync

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** หน้าจอเต็มตอนปลุก: บอกว่าแม่สั่งอะไร พร้อมปุ่ม รับทราบแล้ว / ทำเสร็จแล้ว */
class AlarmActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var box: LinearLayout
    private var shown = ""
    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#7d0d0d"))
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(48), dp(20), dp(24))
        sv.addView(box)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        shown = ""
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun tv(t: String, size: Float): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(Color.WHITE)
        v.gravity = Gravity.CENTER
        v.setPadding(0, dp(12), 0, dp(12))
        return v
    }

    private fun bigBtn(t: String, bg: String, f: () -> Unit): Button {
        val bt = Button(this)
        bt.text = t
        bt.textSize = 22f
        bt.isAllCaps = false
        bt.minHeight = dp(76)
        bt.setTextColor(Color.parseColor("#7d0d0d"))
        bt.setBackgroundColor(Color.parseColor(bg))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        bt.layoutParams = lp
        bt.setOnClickListener { f() }
        return bt
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        val list = parseTasks(Store.tasksJson(this), Store.memberId(this))
            .filter { Alarms.isRinging(it, now) }
        if (list.isEmpty()) {
            finish()
            return
        }
        val sig = list.joinToString(",") { it.id }
        if (sig == shown) return
        shown = sig
        box.removeAllViews()
        box.addView(tv("⏰ แม่สั่งงาน!", 30f))
        for (t in list) {
            box.addView(tv(t.title, 30f))
            box.addView(bigBtn("ทำเสร็จแล้ว", "#69db7c") { act(t.id, "done") })
            box.addView(bigBtn("รับทราบแล้ว", "#ffffff") { act(t.id, "ack") })
        }
    }

    private fun act(id: String, st: String) {
        Store.setStatus(this, id, st)
        val room = Store.room(this)
        val body = if (st == "ack") {
            "{\"status\":\"ack\",\"ackAt\":{\".sv\":\"timestamp\"}}"
        } else {
            "{\"status\":\"done\",\"doneAt\":{\".sv\":\"timestamp\"}}"
        }
        Thread { Api.sendRetry("rooms/$room/tasks/$id", "PATCH", body) }.start()
        shown = ""
        refresh()
    }
}
